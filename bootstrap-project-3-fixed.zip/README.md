# Favorite Ice Cream Project

This is a simple Bootstrap webpage built for class using the Bootstrap 5 framework.

It includes:
- A responsive 3-column layout
- Bootstrap icons and utility classes
- Buttons, spacing, and a custom section
- Navigation bar, header, and footer

The layout is mobile-friendly and designed using best practices from W3 and Bootstrap documentation.
